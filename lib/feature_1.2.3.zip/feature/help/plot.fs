plot.fs               package:feature               R Documentation

_F_e_a_t_u_r_e _s_i_g_n_f_i_c_a_n_c_e _p_l_o_t _f_o_r _1- _t_o _3-_d_i_m_e_n_s_i_o_n_a_l _d_a_t_a

_D_e_s_c_r_i_p_t_i_o_n:

     Feature signficance plot for 1- to 3-dimensional data.

_U_s_a_g_e:

     ## S3 method for class 'fs':
     plot(x, ..., xlab, ylab, zlab, xlim, ylim, zlim,
        add=FALSE, addData=FALSE, scaleData=FALSE, addDataNum=1000,
        addKDE=TRUE, jitterRug=TRUE,  
        addSignifGradRegion=FALSE, addSignifGradData=FALSE,
        addSignifCurvRegion=FALSE, addSignifCurvData=FALSE,
        addAxes3d=TRUE, densCol, dataCol="black", gradCol="green4",
        curvCol="blue", axisCol="black", bgCol="white",
        dataAlpha=0.1, gradDataAlpha=0.3, gradRegionAlpha=0.2,
        curvDataAlpha=0.3, curvRegionAlpha=0.3)

_A_r_g_u_m_e_n_t_s:

       x: an object of class 'fs' (output from 'featureSignif'
          function)

xlim, ylim, zlim: x-, y-, z-axis limits

xlab, ylab, zlab: x-, y-, z-axis labels

scaleData: flag for scaling the data i.e. transforming to unit variance
          for each dimension

     add: flag for adding to an existing plot

 addData: flag for display of the data

addDataNum: maximum number of data points plotted in displays

  addKDE: flag for display of kernel density estimates

jitterRug: flag for jittering of rug-plot for univariate  data display

addSignifGradRegion: flag for display of significant gradient regions

addSignifGradData: flag for display of significant gradient data points

addSignifCurvRegion: flag for display of significant curvature regions

addSignifCurvData: flag for display of significant curvature data
          points

addAxes3d: flag for displaying axes in 3-d displays

 densCol: colour of density estimate curve

 dataCol: colour of data points

 gradCol: colour of significant gradient regions points

 curvCol: colour of significant curvature regions points

 axisCol: colour of axes

   bgCol: colour of background

dataAlpha: transparency of data points

gradDataAlpha: transparency of significant gradient data points

gradRegionAlpha: transparency of significant gradient regions

curvDataAlpha: transparency of significant curvature data points

curvRegionAlpha: transparency of significant curvature regions

     ...: other graphics parameters

_V_a_l_u_e:

     Plot of 1-d and 2-d kernel density estimates are sent to graphics
     window. Plot for 3-d is sent to RGL window.

_S_e_e _A_l_s_o:

     'featureSignif'

_E_x_a_m_p_l_e_s:

     library(MASS)
     data(geyser)
     fs <- featureSignif(geyser, bw=c(4.5, 0.37))
     plot(fs, addKDE=FALSE, addData=TRUE)  ## data only
     plot(fs, addKDE=TRUE)                 ## KDE plot only
     plot(fs, addSignifGradRegion=TRUE)    
     plot(fs, addKDE=FALSE, addSignifCurvRegion=TRUE)
     plot(fs, addSignifCurvData=TRUE, curvCol="cyan")

