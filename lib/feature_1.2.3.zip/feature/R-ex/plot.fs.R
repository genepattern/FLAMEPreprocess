### Name: plot.fs
### Title: Feature signficance plot for 1- to 3-dimensional data
### Aliases: plot.fs
### Keywords: hplot

### ** Examples

library(MASS)
data(geyser)
fs <- featureSignif(geyser, bw=c(4.5, 0.37))
plot(fs, addKDE=FALSE, addData=TRUE)  ## data only
plot(fs, addKDE=TRUE)                 ## KDE plot only
plot(fs, addSignifGradRegion=TRUE)    
plot(fs, addKDE=FALSE, addSignifCurvRegion=TRUE)
plot(fs, addSignifCurvData=TRUE, curvCol="cyan")



