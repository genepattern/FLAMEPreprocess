### Name: featureSignifGUI
### Title: GUI for feature significance for kernel density estimation
### Aliases: featureSignifGUI
### Keywords: smooth

### ** Examples

## Not run: 
##D library(MASS)
##D data(geyser)
##D duration <- geyser$duration 
##D featureSignifGUI(duration)  ## univariate example
##D featureSignifGUI(geyser)    ## bivariate example 
##D 
##D data(earthquake)            ## trivariate example
##D earthquake$depth <- -log10(-earthquake$depth)
##D featureSignifGUI(earthquake,  scaleData=TRUE)
## End(Not run)



