### Name: SiZer
### Title: SiZer plot for 1-dimensional data
### Aliases: SiZer
### Keywords: hplot

### ** Examples

data(earthquake)
eq3 <- -log10(-earthquake[,3])
SiZer(eq3, xlab="-log(-depth)")
SiZer(eq3, xlab="-log(-depth)", bw=c(0.05, 1.3), gridsize=401)



