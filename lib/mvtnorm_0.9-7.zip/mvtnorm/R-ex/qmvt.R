### Name: qmvt
### Title: Quantiles of the Multivariate t Distribution
### Aliases: qmvt
### Keywords: distribution

### ** Examples

qmvt(0.95, df = 16, tail = "both")



