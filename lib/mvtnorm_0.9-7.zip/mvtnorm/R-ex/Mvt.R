### Name: Mvt
### Title: The Multivariate t Distribution
### Aliases: dmvt rmvt
### Keywords: distribution multivariate

### ** Examples


  dmvt(x=c(0,0), sigma = diag(2))
  x <- rmvt(n=100, sigma = diag(2), df = 3)
  plot(x)




