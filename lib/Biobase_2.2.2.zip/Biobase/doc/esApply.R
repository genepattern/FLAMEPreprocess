###################################################
### chunk number 1: R.hide
###################################################
library(Biobase)
data(sample.ExpressionSet)


###################################################
### chunk number 2: R
###################################################
print(sample.ExpressionSet)
print(exprs(sample.ExpressionSet)[1,])
print(pData(sample.ExpressionSet)[1:2,1:3])


###################################################
### chunk number 3: R
###################################################
print(rbind(exprs(sample.ExpressionSet[1,]),
sex <- t(pData(sample.ExpressionSet))[1,]))


###################################################
### chunk number 4: R
###################################################
medContr <- function( y, x ) {
 ys <- split(y,x)
 median(ys[[1]]) - median(ys[[2]])
}


###################################################
### chunk number 5: R
###################################################
print(apply(exprs(sample.ExpressionSet[1,,drop=F]), 1,
  medContr, pData(sample.ExpressionSet)[["sex"]]))


###################################################
### chunk number 6: R
###################################################
medContr1 <- function(y) {
 ys <- split(y,sex)
 median(ys[[1]]) - median(ys[[2]])
}

print(esApply( sample.ExpressionSet, 1, medContr1)[1])


###################################################
### chunk number 7: 
###################################################
sessionInfo()


