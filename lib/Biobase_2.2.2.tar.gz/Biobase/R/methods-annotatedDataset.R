setMethod("initialize", "annotatedDataset",
		function(.Object, ...) {
			.Defunct(msg="The annotatedDataset class is defunct")
		})
