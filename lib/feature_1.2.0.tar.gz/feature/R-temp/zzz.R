.First <- function()
{
  require(rgl)
  require(misc3d)
}
